export { default as firebaseDatabase, admin } from "./firebase.database.js";
