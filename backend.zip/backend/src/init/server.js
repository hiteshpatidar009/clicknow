import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import morgan from "morgan";
import env from "../config/env.loader.js";

import { appConfig } from "../config/index.js";
import { firebaseDatabase } from "../database/index.js";

import routes from "../routes/index.js";

import {
  notFoundHandler,
  errorHandler,
  defaultLimiter,
  requestLoggerWithExclusions,
} from "../middlewares/index.js";

import Logger from "../utils/logger.util.js";

const app = express();

import connectDB from "../config/db.js";

const resolveCorsOrigins = () => {
  const configured = String(env.CORS_ORIGIN || "").trim();
  if (!configured || configured === "*") {
    return true;
  }

  const origins = configured
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

  return (origin, callback) => {
    // Allow server-to-server and curl requests without an Origin header.
    if (!origin) return callback(null, true);
    if (origins.includes(origin)) return callback(null, true);
    return callback(new Error(`CORS blocked for origin: ${origin}`));
  };
};

/**
 * Initialize server
 */
async function initializeServer() {
  try {
    Logger.info("> Initializing MongoDB connection...");
    const isMongoConnected = await connectDB();
    if (isMongoConnected) {
      Logger.info("✓ MongoDB initialized successfully");
    } else {
      Logger.warn("!! MongoDB unavailable - continuing in degraded mode");
    }

    Logger.info("> Initializing Firebase connection...");
    if (
      env.FIREBASE_PROJECT_ID &&
      env.FIREBASE_PROJECT_ID !== "photography-app-dev"
    ) {
      firebaseDatabase.initialize();
    } else {
      Logger.warn("!! Firebase not configured - running in mock mode");
    }

    app.set("trust proxy", 1);

    app.use(
      helmet({
        contentSecurityPolicy: false,
        crossOriginEmbedderPolicy: false,
      }),
    );

    app.use(
      cors({
        origin: resolveCorsOrigins(),
        methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
        credentials: true,
        maxAge: 86400,
      }),
    );

    app.use(express.json({ limit: "10mb" }));
    app.use(express.urlencoded({ extended: true, limit: "10mb" }));

    app.use(compression());

    if (
      process.env.NODE_ENV !== "production" &&
      process.env.SILENT_HTTP_LOGS !== "true"
    ) {
      app.use(morgan("dev"));
    }

    app.use(requestLoggerWithExclusions(["/api/v1/health"]));
    app.use("/api", defaultLimiter);
    app.use("/api/v1", routes);

    app.get("/", (req, res) => {
      res.type("text/plain").send("Photography App API v1.0.0");
    });

    app.get("/health", (req, res) => {
      res
        .type("text/plain")
        .send(
          `healthy | ${process.env.NODE_ENV || "development"} | uptime: ${process.uptime().toFixed(0)}s`,
        );
    });

    app.use(notFoundHandler);
    app.use(errorHandler);

    const PORT = env.PORT;
    const server = app.listen(PORT, () => {
      Logger.info(`Server started on port ${PORT}`);
      Logger.info(`Environment: ${env.NODE_ENV}`);
      Logger.info(`API URL: http://localhost:${PORT}/api/v1`);
    });

    const gracefulShutdown = (signal) => {
      Logger.info(`${signal} received. Starting graceful shutdown...`);

      server.close(() => {
        Logger.info("HTTP server closed");
        process.exit(0);
      });

      setTimeout(() => {
        Logger.error("Forced shutdown after timeout");
        process.exit(1);
      }, 30000);
    };

    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));

    process.on("uncaughtException", (error) => {
      Logger.error("Uncaught Exception", error);
      process.exit(1);
    });

    process.on("unhandledRejection", (reason, promise) => {
      Logger.error("Unhandled Rejection", { reason, promise });
    });

    return server;
  } catch (error) {
    Logger.error("Failed to initialize server", error);
    process.exit(1);
  }
}

export { app, initializeServer };
