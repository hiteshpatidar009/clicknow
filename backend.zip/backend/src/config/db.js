import mongoose from 'mongoose';

const FIREBASE_UID_INDEX_NAME = "firebaseUid_1";
const FIREBASE_UID_INDEX_SPEC = { firebaseUid: 1 };
const FIREBASE_UID_PARTIAL_FILTER = {
  firebaseUid: { $exists: true, $type: "string" },
};

function isExpectedFirebaseUidIndex(index) {
  if (!index || index.name !== FIREBASE_UID_INDEX_NAME) return false;

  const keyMatches = JSON.stringify(index.key) === JSON.stringify(FIREBASE_UID_INDEX_SPEC);
  const partialMatches =
    JSON.stringify(index.partialFilterExpression || {}) ===
    JSON.stringify(FIREBASE_UID_PARTIAL_FILTER);

  return index.unique === true && keyMatches && partialMatches;
}

async function ensureFirebaseUidIndex() {
  const usersCollection = mongoose.connection.collection("users");
  const indexes = await usersCollection.indexes();
  const firebaseUidIndex = indexes.find((idx) => idx.name === FIREBASE_UID_INDEX_NAME);

  if (firebaseUidIndex && !isExpectedFirebaseUidIndex(firebaseUidIndex)) {
    await usersCollection.dropIndex(FIREBASE_UID_INDEX_NAME);
    console.log("Dropped legacy users.firebaseUid_1 index");
  }

  const refreshedIndexes = await usersCollection.indexes();
  const hasExpectedIndex = refreshedIndexes.some(isExpectedFirebaseUidIndex);

  if (!hasExpectedIndex) {
    await usersCollection.updateMany(
      { firebaseUid: "" },
      { $unset: { firebaseUid: "" } },
    );
    await usersCollection.createIndex(FIREBASE_UID_INDEX_SPEC, {
      name: FIREBASE_UID_INDEX_NAME,
      unique: true,
      partialFilterExpression: FIREBASE_UID_PARTIAL_FILTER,
    });
    console.log("Created partial unique users.firebaseUid_1 index");
  }
}

const connectDB = async () => {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error("MONGODB_URI is not set");
    }

    const conn = await mongoose.connect(process.env.MONGODB_URI);
    await ensureFirebaseUidIndex();

    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    const allowWithoutMongo =
      process.env.NODE_ENV !== "production" &&
      (process.env.ALLOW_START_WITHOUT_MONGO || "true").toLowerCase() === "true";

    if (allowWithoutMongo) {
      console.warn(`MongoDB connection skipped in development: ${error.message}`);
      return false;
    }

    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
