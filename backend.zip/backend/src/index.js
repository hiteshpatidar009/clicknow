import "./init/startup.js";
